\documentclass{article}
\usepackage{listings}
\begin{document}
\begin{lstlisting}



\end{lstlisting}
\end{document}